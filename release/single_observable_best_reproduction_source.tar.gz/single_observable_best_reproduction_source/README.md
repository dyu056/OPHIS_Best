# Best single-observable result reproduction source

This package contains the exact remote source snapshot used by the best completed
single-observable learning-hyperparameter trial.

## Original result

- `val_bpb`: `0.9305633662309044`
- baseline `val_bpb`: `0.9344166733521407`
- seed: `42`
- training steps: `2000`
- observable: `val.layer_2.attn_out.l1`
- trajectory coefficient: `0.007`
- lead: `100` steps
- cutoff: step `750`
- `MATRIX_LR`: `0.045`
- `NGRAM_VE_BETAS`: `(0.5, 0.9995)`
- `NGRAM_VE_LR_SCALE`: `1.2`
- `NGRAM_VE_BETA2_WARMDOWN`: `0.99995`

## Contents

- `source/`: exact downloaded training source, dependency lockfile, target curve,
  command configuration, and original generated summary.
- `original_result/`: local audit records, original training log, and later
  replicate-run records.
- `reproduce.py`: isolated rerun launcher that copies the source into a fresh workdir.
- `SHA256SUMS`: integrity manifest for every packaged file except itself.

## Run

Use the same dataset mount and Python environment as the original experiment:

```bash
/home/user/ph/autoresearch/.venv/bin/python reproduce.py \
  --python /home/user/ph/autoresearch/.venv/bin/python \
  --gpu 1 \
  --output-dir rerun
```

The rerun writes `rerun/train.log` and `rerun/summary.json`.

## Reproducibility note

A later same-configuration replicate produced `val_bpb=0.9330607019393208`.
It still beat the baseline, but did not reproduce the original best value within
`0.001`. The package preserves the exact code/configuration; bitwise metric
reproduction is not guaranteed by the CUDA training stack.
